const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const toast=$('#toast');let timer;
function showToast(m){if(!toast)return;toast.textContent=m;toast.classList.add('show');clearTimeout(timer);timer=setTimeout(()=>toast.classList.remove('show'),2400)}
window.showToast=showToast;

$$('[data-nav]').forEach(b=>b.addEventListener('click',()=>{const href=b.dataset.href;if(href)location.href=href}));

function getSaved(){try{return JSON.parse(localStorage.getItem('sanad_saved')||'[]')}catch(e){return[]}}
function setSaved(v){localStorage.setItem('sanad_saved',JSON.stringify(v))}
function toggleSave(id,label,kind='مرجع'){
  const items=getSaved(); const i=items.findIndex(x=>x.id===id);
  if(i>=0){items.splice(i,1);showToast('أزيل من المحفوظات')}else{items.unshift({id,label,kind,savedAt:new Date().toISOString()});showToast('حُفظ في المحفوظات')}
  setSaved(items); refreshSaveButtons(); if(typeof renderBookmarks==='function') renderBookmarks();
}
window.toggleSave=toggleSave;
function refreshSaveButtons(){$$('[data-save]').forEach(btn=>{const yes=getSaved().some(x=>x.id===btn.dataset.save);btn.textContent=yes?'★ محفوظ':'☆ حفظ';btn.classList.toggle('saved',yes)})}

const searchForm=$('#searchForm');if(searchForm)searchForm.addEventListener('submit',e=>{e.preventDefault();const q=$('#searchInput').value.trim();if(!q)return showToast('اكتب ما تريد البحث عنه أولًا');location.href='search.html?q='+encodeURIComponent(q)});

function allRecords(){const d=window.SANAD_DATA||{};return [...(d.quran||[]),...(d.hadith||[]),...(d.books||[])];}
function normalize(s=''){return s.toLowerCase().replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').replace(/[ًٌٍَُِّْـ]/g,'')}
function searchRecords(q){const n=normalize(q);return allRecords().filter(x=>normalize([x.title,x.arabic,x.ref,x.note,x.author,x.field,...(x.tags||[])].filter(Boolean).join(' ')).includes(n))}
window.searchRecords=searchRecords;

function renderSearch(){const host=$('#searchResults');if(!host)return;const params=new URLSearchParams(location.search);const q=params.get('q')||'';const input=$('#globalSearchInput');if(input)input.value=q;const results=q?searchRecords(q):allRecords();$('#searchCount').textContent=q?`${results.length} نتيجة لـ «${q}»`:`${results.length} مادة نموذجية`;
  host.innerHTML=results.map(item=>`<article class="result-card"><div class="result-top"><span class="status ${item.type==='quran'?'ok':item.type==='hadith'?'info':'warn'}">${item.type==='quran'?'قرآن':item.type==='hadith'?'حديث':'كتاب'}</span><button class="mini-action" data-save="${item.id}" onclick="toggleSave('${item.id}','${(item.title||'').replace(/'/g,'')}','${item.type||'مرجع'}')">☆ حفظ</button></div><h3>${item.title}</h3>${item.arabic?`<div class="arabic-text">${item.arabic}</div>`:''}<p>${item.note||item.field||''}</p><div class="meta-line">${item.ref||[item.author,item.field].filter(Boolean).join(' · ')}</div>${item.url?`<a class="text-link" href="${item.url}" target="_blank" rel="noopener">فتح المرجع ↗</a>`:''}</article>`).join('')||`<div class="empty-state">لم نعثر على نتيجة ضمن البيانات النموذجية. في النسخة المتصلة بالخادم سيُوسَّع البحث ليشمل قاعدة الكتب والمصادر المعتمدة.</div>`;refreshSaveButtons();}
window.renderSearch=renderSearch;

function renderQuran(){const host=$('#quranList');if(!host||!SANAD_DATA)return;host.innerHTML=SANAD_DATA.quran.map(v=>`<article class="panel source-detail"><div class="result-top"><span class="status ok">نص قرآني</span><button class="mini-action" data-save="${v.id}" onclick="toggleSave('${v.id}','${v.title}','قرآن')">☆ حفظ</button></div><h2>${v.title}</h2><div class="quran-verse">${v.arabic}</div><p>${v.note}</p><div class="source-proof"><strong>المرجع:</strong> ${v.ref}</div><a class="primary-link" href="${v.url}" target="_blank" rel="noopener">فتح موضع الآية ↗</a></article>`).join('');refreshSaveButtons()}
window.renderQuran=renderQuran;

function renderHadith(){const host=$('#hadithList');if(!host||!SANAD_DATA)return;host.innerHTML=SANAD_DATA.hadith.map(h=>`<article class="panel source-detail"><div class="result-top"><span class="status ok">${h.grade}</span><button class="mini-action" data-save="${h.id}" onclick="toggleSave('${h.id}','${h.title}','حديث')">☆ حفظ</button></div><h2>${h.title}</h2><div class="arabic-text">${h.arabic}</div><p><strong>الراوي:</strong> ${h.narrator}</p><p>${h.note}</p><div class="source-proof"><strong>المرجع:</strong> ${h.ref}</div><a class="primary-link" href="${h.url}" target="_blank" rel="noopener">فتح التخريج ↗</a></article>`).join('');refreshSaveButtons()}
window.renderHadith=renderHadith;

function renderBooks(filter=''){const host=$('#bookGrid');if(!host||!SANAD_DATA)return;const n=normalize(filter);const books=SANAD_DATA.books.filter(b=>!n||normalize([b.title,b.author,b.field].join(' ')).includes(n));host.innerHTML=books.map(b=>`<article class="book-card"><div class="book-spine">▤</div><div><span class="status info">${b.status}</span><h3>${b.title}</h3><p class="muted">${b.author}</p><p>${b.field}</p><small>${b.note}</small></div><button class="mini-action" data-save="${b.id}" onclick="toggleSave('${b.id}','${b.title}','كتاب')">☆ حفظ</button></article>`).join('')||'<div class="empty-state">لا توجد كتب مطابقة في المكتبة النموذجية.</div>';refreshSaveButtons()}
window.renderBooks=renderBooks;

function renderTracks(){const host=$('#trackGrid');if(!host||!SANAD_DATA)return;host.innerHTML=SANAD_DATA.tracks.map(t=>`<article class="track-card"><div class="track-icon">${t.icon}</div><h3>${t.title}</h3><ul>${t.lessons.map(x=>`<li>${x}</li>`).join('')}</ul><button class="secondary" onclick="showToast('سيتم ربط تقدم الدروس بالحساب في النسخة الرسمية')">ابدأ المسار</button></article>`).join('')}
window.renderTracks=renderTracks;

function renderBookmarks(){const host=$('#bookmarkList');if(!host)return;const items=getSaved();host.innerHTML=items.length?items.map(x=>`<article class="bookmark-row"><div><span class="status info">${x.kind}</span><h3>${x.label}</h3><small>${new Date(x.savedAt).toLocaleDateString('ar')}</small></div><button class="secondary" onclick="toggleSave('${x.id}','${(x.label||'').replace(/'/g,'')}','${x.kind}')">إزالة</button></article>`).join(''):'<div class="empty-state"><div class="big-icon">☆</div><h3>لا توجد محفوظات بعد</h3><p>استخدم زر «حفظ» في الآيات والأحاديث والكتب لتظهر هنا.</p></div>'}
window.renderBookmarks=renderBookmarks;

const askForm=$('#askForm');if(askForm)askForm.addEventListener('submit',e=>{e.preventDefault();const q=$('#askQuestion').value.trim();if(!q)return showToast('اكتب سؤالك أولًا');const panel=$('#sampleAnswer'); const matches=searchRecords(q); let html='';
if(matches.length){html=`<div class="panel"><div class="result-top"><span class="status ok">مصدر مطابق في البيانات النموذجية</span><span class="status info">بحث محلي</span></div><h2>نتيجة موثقة</h2>${matches.slice(0,3).map(item=>`<div class="claim"><strong>${item.title}</strong>${item.arabic?`<div class="arabic-text compact">${item.arabic}</div>`:''}<p>${item.note||''}</p><div class="meta-line">${item.ref||item.author||''}</div>${item.url?`<a class="text-link" target="_blank" rel="noopener" href="${item.url}">فتح المرجع ↗</a>`:''}</div>`).join('')}<div class="claim warn"><strong>حدود هذه النسخة</strong><p>هذا البحث يعمل داخل مجموعة بيانات نموذجية صغيرة فقط. لا يُعرض أي جواب حر على أنه فتوى أو تحقيق شامل قبل ربط قاعدة المصادر ومحرك التحقق الخلفي.</p></div></div>`}else{html=`<div class="panel"><span class="status warn">مصادر غير كافية في النسخة المحلية</span><h2>لم نجد مادة كافية للجزم</h2><p>بدل توليد جواب غير موثق، يتوقف سَنَد هنا. في النسخة الرسمية سيبحث الخادم في المصادر المعتمدة ثم يمرر كل ادعاء إلى مرحلة المطابقة قبل العرض.</p><a class="secondary inline-btn" href="sources.html">راجع منهج التوثيق</a></div>`}
panel.innerHTML=html;panel.hidden=false;panel.scrollIntoView({behavior:'smooth',block:'start'})});

const verifyForm=$('#verifyForm');if(verifyForm)verifyForm.addEventListener('submit',e=>{e.preventDefault();const text=$('#verifyText').value.trim();if(!text)return showToast('ألصق النص أولًا');const n=normalize(text);const found=allRecords().filter(x=>x.arabic&&n.includes(normalize(x.arabic.replace(/[«»﴿﴾]/g,'').slice(0,18)))||x.arabic&&normalize(x.arabic).includes(n));const host=$('#verifyResult');if(found.length){host.innerHTML=`<div class="panel"><span class="status ok">عُثر على تطابق</span><h2>أقرب أصل في البيانات النموذجية</h2>${found.map(x=>`<div class="sourcecard"><strong>${x.title}</strong><div class="arabic-text compact">${x.arabic}</div><div class="meta-line">${x.ref}</div>${x.url?`<a class="text-link" href="${x.url}" target="_blank" rel="noopener">فتح المرجع ↗</a>`:''}</div>`).join('')}<p class="verification-note">وجود التطابق النصي لا يغني في النسخة الرسمية عن فحص السياق والرواية والطبعة ونسبة الحكم.</p></div>`}else{host.innerHTML=`<div class="panel"><span class="status warn">لم يُعثر على أصل في النطاق المفحوص</span><h2>لا يمكن الجزم بصحة النسبة</h2><p>لم نعثر على النص ضمن البيانات النموذجية المحلية. هذه النتيجة لا تعني أن النص باطل؛ بل تعني فقط أن النطاق الحالي غير كافٍ، وهي الصياغة التي نعتمدها بدل الحكم بلا بينة.</p></div>`}host.hidden=false;host.scrollIntoView({behavior:'smooth'})});

function applyPrefs(){const compact=localStorage.getItem('sanad_compact')==='1';document.documentElement.classList.toggle('compact-ui',compact)}
window.setCompact=v=>{localStorage.setItem('sanad_compact',v?'1':'0');applyPrefs();showToast('تم حفظ تفضيل العرض')};
applyPrefs();refreshSaveButtons();
