const CACHE='sanad-html-v3';
const ASSETS=['index.html','styles.css','app.js','data.js','logo.jpeg','ask.html','search.html','library.html','verify.html','quran.html','hadith.html','fiqh.html','compare.html','student.html','bookmarks.html','account.html','about.html','sources.html'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(resp=>{const copy=resp.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return resp}).catch(()=>caches.match('index.html'))))});
